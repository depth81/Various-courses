def sumar(a,b):
    print("Suma: ", a+b)

def restar(a,b):
    print("Resta: ", a-b)

def Multiplicar(a,b):
    print("Producto: ", a*b)

def dividir(a,b):
    print("División: ", a/b)

def potencia(b, e):
    print("Potencia: ", b**e)

def redondear(n):
    print("Redondeo: ", round(n))