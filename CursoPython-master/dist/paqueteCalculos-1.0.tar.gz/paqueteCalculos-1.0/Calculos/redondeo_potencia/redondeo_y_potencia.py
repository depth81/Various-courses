def potencia(b, e):
    print("Potencia: ", b**e)

def redondear(n):
    print("Redondeo: ", round(n))